Arch Packaging Files
--------------------

The PKGBUILD in this directory is here for reference.
You should use AUR to install [ansible-git][1], using `yaourt` for instance:

    yaourt -S ansible-git

You can also use a AUR package for the stable version of [ansible][2].

  [1]: https://aur.archlinux.org/packages/ansible-git/
  [2]: https://aur.archlinux.org/packages/ansible/

